doc_types = ('.doc', '.docx', '.txt', '.pdf', '.xls', '.ppt', '.xlsx', '.pptx')
img_types = ('.jpg', '.jpeg', '.png', '.svg', '.gif')
software_types = ('.exe', '.py', '.ipynb')
CARPETAS = ["Documentos", "Imagenes", "Software", "Otros"]
